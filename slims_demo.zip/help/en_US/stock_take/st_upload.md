### Upload List
<hr>
This menu is used to perform automated stock-take using a data file listing the items. To be able to use the Upload List, first the data items should be exported from Senayan, then specific items are stored in a .txt file in rows.
