#### Initialize
<hr>
The Initialize menu is used to start stock-taking. In this menu, there are the following sub-menus:
- StockTake Name: the name of the stock-taking activities undertaken. Customize the name to your liking. This field MUST be filled.
- GMD: (See the module guide Master File -> GMD (below Authority Files)). 
- Collection Type: (See the module guide Master File -> Collection Type (under Lookup Files)).
- Location: (See the module guide Master File -> Location (below Authority Files)).
- Shelf Location: referring to the information item in the Bibliography module.
- Classification: Referring to the classification field in the Bibliography module. For defining a classification range use the wildcard (*), For example, if we want to do stock-taking of classifications with a range of 100 through to 300, just enter 1* to 3*. If the range of classifications we stock-take is in the 100's, enter 1 *.

After the Initialization is done, the Current StockTake menu and StockTake Report will serve as menus for stock-take activities, coupled with the navigation menu to be used to conduct a stock-take along with the StockTake Finish menu, Current Lost Items, StockTake Log, and Resynchronise.
