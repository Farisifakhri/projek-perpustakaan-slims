### StockTake Report
<hr>
Use this menu to see the results of the activities that have been performed in stock-take. The form of the report contains information about the number of items checked, items lost, and number of items on loan. This menu does not work if the Initialization is not done.
