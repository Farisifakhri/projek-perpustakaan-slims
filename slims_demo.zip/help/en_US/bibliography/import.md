#### Import Data
<hr>
The “Import Data” menu is used to retrieve bibliographic data from outside SLiMS in csv format (or from a database that has been exported from Senayan in csv format), and then subsequently include it in Senayan. 
