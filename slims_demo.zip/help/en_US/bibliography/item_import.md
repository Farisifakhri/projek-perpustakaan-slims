#### Import Item
<hr>
Item import is used to insert item data into a SLiMS database. If this activity is done from a single SLiMS database to another SLiMSr, then the item import is done after bibliography import. This means the item will adjust the bibliographic data that has been imported earlier.