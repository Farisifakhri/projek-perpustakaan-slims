###Holiday Settings

A facility to determine days off, where the library is not open for service. Defining these holidays will effect calculation of weekdays the library is active/open, and fine calculation. There are two types of holidays that can be defined in this menu:
- Regular days off (Monday till Sunday), and 
- Special holidays (defined by date, month and year).

To Set Holidays, librarians just choose the day(s) that is a routine holiday . For the Add Special Holiday, librarians can determine the date, month, year and description of the holiday. In addition, Special Holidays can also be configured with a range of time-off (from the start date until the date of completion of holidays).
