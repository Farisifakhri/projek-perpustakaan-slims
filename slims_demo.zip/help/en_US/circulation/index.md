###Begin transaction

To make transactions via the Member ID (ID of member). Once Member ID is inserted, it will display the member's information, namely: 
- Member Name (name of member), 
- Member E-Mail (member's email address), 
- Register Date (date the member registered), 
- Member ID (member ID ), 
- Member Type (type of membership), 
- Expiry date (membership end date), and 
- member photo. 

Underneath there are tabs: 
- Loans (to make borrowing transactions), 
- Current Loans (list the current loans the member has), 
- Reserve (for ordering literature needs), 
- Fines (fines), 
- Loan History (history of borrowing undertaken by the member). 

In Current Loans there are also facilities for returns (Return) and to extend lending (Extend).
