####Export Data

This menu is used to retrieve the membership data within the Senayan application, and the result is data output as a .csv file.
