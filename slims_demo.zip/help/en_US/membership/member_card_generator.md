####Member Card Printing

This menu is used to print the member card. Printing method is similar to barcode label printing. The information contained in this membership card is: 
- ID, 
- Name, 
- Member Type, 
- Barcode, 
- Photo (if any), and 
- Name of the Library
