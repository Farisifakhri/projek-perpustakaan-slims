#### Lista de ejemplares
<hr>
Este menú se utiliza para ver los ejemplares de la base de datos de Senayan. La información contenida en este menú es: 
- Código del ejemplar,
- Título, 
- Tipo de colección, 
- Ubicación, 
- Clasificación 
- Última actualización. 
Este menú también se puede utilizar para editar y borrar ejemplares.