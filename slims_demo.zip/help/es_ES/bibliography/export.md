#### Exportar datos
<hr>
El menú Exportar datos se utiliza para obtener los datos bibliográficos de una aplicación SLiMS, para luego ser incluida en otra aplicación distinta a Senayan. Este proceso puede entenderse como un intercambio de datos.
