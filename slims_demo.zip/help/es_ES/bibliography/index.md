#### Añadir un nuevo registro
<hr>
Este menú se utiliza para añadir un nuevo registro bibliográfico. Para hacerlo, haga clic en Añadir un nuevo registro. Luego tendrá que brindar todos los datos necesarios del mismo.