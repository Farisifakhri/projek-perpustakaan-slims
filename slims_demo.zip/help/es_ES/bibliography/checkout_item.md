#### Comprobar ejemplares
<hr>
Este menú proporciona información sobre el ejemplar prestado. También ofrece un servicio de búsqueda para encontrar ejemplares y títulos bibliográficos. La información contenida en este menú es: 
- Código del ejemplar, 
- ID del miembro prestatario, 
- Título, 
- Fecha del préstamo (cuando se prestó), 
- Fecha de vencimiento (fecha de devolución).