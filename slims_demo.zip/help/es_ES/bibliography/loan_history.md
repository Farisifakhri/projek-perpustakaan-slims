####Historial de préstamos
Contiene los datos de las transacciones de los ejemplares de la colección que han sido prestados.
Los datos que aparecen constan de:
- Identificación del miembro,
- Nombre del miembro,
- Código del ejemplar,
- Título,
- Fecha del préstamo,
- Fecha de vencimiento.

En este menú también hay una opción para imprimir la lista del historial de préstamos.
Además, también es posible buscar en dicho historial.

Esta búsqueda de datos históricos se basa en:
- Identificación del miembro/Nombre de usuario,
- Título del documento,
- Código del ejemplar,
- Fecha de préstamo
- Fecha de vencimiento.

La consulta de los campos se puede mostrar haciendo clic en Mostrar más opciones de filtro.
