#### Imprimir del catálogo
<hr>
Esta función se puede utilizar para imprimir un catálogo de tarjetas (por autor, tema, título, etc.). La impresión es similar a la impresión de un código de barras o etiqueta de libro.