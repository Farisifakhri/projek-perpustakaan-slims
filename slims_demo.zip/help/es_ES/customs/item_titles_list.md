### Lista de títulos de ejemplares

Contiene informes/listas de los ejemplares de los títulos en poder de la biblioteca. En este menú hay una función para ordenar e imprimir, así como una colección de filtros útiles. En el mismo, el filtrado también se puede hacer escribiendo el Título/ISBN, o mediante la aplicación de otros filtros. Para ello, haga clic en "Mostrar más opciones de filtro". Los filtros disponibles son:
- Título/ISBN,
- Código del ejemplar,
- Clasificación,
- Tipo de colección,
- Estado del ejemplar,
- Ubicación.

Estas funciones de filtro se pueden ocultar nuevamente haciendo clic en "Ocultar más opciones de filtro".
