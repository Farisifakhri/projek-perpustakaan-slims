#### Informe de multas

Este es un informe basado en el número de miembros multados por cada día.