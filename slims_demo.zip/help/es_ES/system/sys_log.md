###Registro del sistema

Este es un menú para ver los procesos registrados llevados a cabo por el sistema de Senayan. Los registros que se producen muestran la hora, la ubicación (nombre del módulo) y el mensaje (descripción). Los mensajes que aparecen en los Registros del sistema incluyen quién (Usuario/Administrador), qué realizó y dónde.

Cuando se empiece a usar la aplicación de Senayan, se registrará automáticamente todo el trabajo y el tamaño y la carga del registro aumentarán. Por lo tanto, los menús del registro del sistema también contienen la función de GUARDAR LOS REGISTROS EN ARCHIVOS. Este proceso guardará el registro existente y luego limpiaremos la pantalla haciendo clic en BORRAR REGISTROS.