###Módulos

Proporciona las funciones de:
- Lista de módulos (listado de todos los módulos existentes),
- Búsqueda (búsqueda de un módulo en específico),
- Editar y Eliminar módulos, y
- Agregar un nuevo módulo (agregar un módulo al sistema).

Para agregar un módulo, la carpeta del módulo ya debe estar ubicada en admin/modules/. Luego haga clic en Agregar nuevo módulo y complete la información del nuevo módulo, a saber:
- Nombre del módulo,
- Ruta del módulo (ruta/ubicación del módulo),
- Descripción del módulo (breve descripción del módulo), y
- luego haga clic en "Guardar".