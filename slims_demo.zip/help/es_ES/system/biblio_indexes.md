###Índices del sistema

Este menú se utiliza para indexar las bases de datos bibliográficas utilizadas por SLiMS. Al realizar esta indexación, se mejorará el rendimiento de las búsquedas de SLiMS.

Hay tres funciones en este menú:
- Eliminar los índices: para borrar los resultados del índice existente,
- Recrear el índice: para volver a indexar la base de datos bibliográfica,
- Actualizar el índice: para indexar los nuevos datos bibliográficos que aún no se han indexado.

Puede localizar la configuración para el tipo de índice dentro de config/sysconfig.local.inc.php.