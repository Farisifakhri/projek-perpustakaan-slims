###Ejemplares perdidos
<hr>
El contenido de este menú es una lista de ejemplares que se consideran desaparecidos al momento de realizar el inventario, además de los ejemplares que se encuentren en préstamo.