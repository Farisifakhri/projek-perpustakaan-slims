###Informe del inventario
<hr>
Use este menú para ver los resultados de las actividades que se han realizado en el inventario. El formulario del informe contiene información sobre el número de ejemplares verificados, los ejemplares perdidos y el número de ejemplares prestados. Este menú no funcionará si no se realiza la inicialización.