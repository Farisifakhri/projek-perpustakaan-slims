####Impresión de tarjetas de miembro

Este menú se utiliza para imprimir la tarjeta de los miembros. El método de impresión es similar a la impresión de etiquetas de los código de barras. La información contenida en esta tarjeta de membresía es:
- Identificador del miembro,
- Nombre,
- Tipo de miembro,
- Código de barras,
- Foto (si existe), y
- Nombre de la biblioteca