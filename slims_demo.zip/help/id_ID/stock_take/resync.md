### Resinkronisasi
<hr>
Silakan melakukan sinkronisasi data bibliografi yang diedit pada saat berlangsung kegiatan stock take dengan data bibliografi yang ada pada modul stock take. Tujuannya adalah untuk menyamakan data jika ada proses edit data ketika inventarisasi telah berlangsung. Klik tombol Resyncronize begitu perubahan data bibliografi sudah dilakukan.
