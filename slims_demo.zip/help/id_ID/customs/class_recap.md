### Rekapitulasi
<hr>
Menu ini menampilkan hasil rekapitulasi koleksi berdasar Classification, GMD, Colection Type atau Language. Pilihan ini dapat kita tentukan dengan memilih filter rekapitulasi yang tersedia. Senayan juga telah mendukung rekap untuk klasifikasi yang bukan didasarkan pada angka desimal. Misalnya REF untuk referensi. 

Custom Recapitulation menyediakan fasilitas Print Current Page untuk mencetak laporan, serta “Export to spreadsheet format” untuk mendapatkan laporan dalam bentuk spreadsheet.