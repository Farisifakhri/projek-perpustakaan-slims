###Peminjaman berdasarkan klas

Merupakan laporan peminjaman berdasarkan Klas. Selain kelas 0-9, pada laporan ini juga dimungkinkan pelaporan berdasarkan kelas 2X dan klas Non Decimal. Peminjaman berdasarkan klas dapat ditapis dengan: 
- Class, 
- Colection Type, dan 
- Year.

Fitur ini juga menyediakan fasilitas unduh file dalam bentuk spreadsheet. File dapat didapatkan dengan klik “Export to spreadsheet format”.
