### Laporan anggota
<hr>
Berisi informasi keanggotaan, yaitu: total anggota yang terdaftar, total anggota aktif, total anggota berdasar tipe anggota, total anggota yang tidak aktif dan daftar 10 (sepuluh) anggota teraktif. 

Laporan yang ada dalam tiga menu tersebut dapat diperoleh dalam format .html dan dapat dicetak dengan klik tombol Download Report

Mulai Senayan3-stable14, ketiga jenis laporan ini dilengkapi dengan fitur cetak grafik berjenis Pie. Untuk mendapatkan Grafik ini cukup dengan klik Show in Chart/Plot yang muncul pada ketiga jenis laporan ini (Collection Statistic, Loan Report dan Membership Report).