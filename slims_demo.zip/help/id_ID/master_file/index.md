####Master File
<hr>
Dalam modul Master File kita dapat memasukkan data yang dapat digunakan sebagai master dalam entry data bibliografi. Data-data yang dapat kita definisikan dalam modul Master File ini adalah:
- GMD General Material Designation – Bentuk fisik koleksi atau media fisik tempat penyimpanan informasi.
