####Master File / Lokasi
<hr>
Gunakan fitur ini untuk mengisi kode lokasi dan nama lokasi penyimpanan koleksi di Perpustakaan.
Contoh: Perpustakaan Fakultas Ekonomi, Perpustakaan Fakultas Psikologi
