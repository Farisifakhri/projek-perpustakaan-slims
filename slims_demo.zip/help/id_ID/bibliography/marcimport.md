####Import MARC
Fitur ini digunakan untuk mengimport data MARC baik itu berekstensi .mrc ataupun .xml.
Sebelum menggunakan fitur ini, syaratnya pada server SLiMS telah terinstall [PEAR](http://pear.php.net/index.php), [FILE_MARC](http://pear.php.net/package/File_MARC) dan [Structures_LinkedList](http://pear.php.net/package/Structures_LinkedList).

<a href = "http://google.com" target="_blank">ini mbah google</a>
